from menu_settings import main_menu

if __name__ == "__main__":
    main_menu()
